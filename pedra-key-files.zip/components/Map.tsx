import React, { useRef, useEffect } from "react";
import mapboxgl from "mapbox-gl";
import { useMap } from "../context/MapContext";

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!;

const Map: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const { setMap } = useMap();

  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;

    const map = new mapboxgl.Map({
      container: containerRef.current,
      style: "mapbox://styles/mapbox/streets-v11",
      center: [-71.0589, 42.3601],
      zoom: 12,
    });

    mapRef.current = map;

    map.on("load", () => {
      console.log("Map loaded");
      setMap(map);
    });

    return () => {
      map.remove();
    };
  }, [setMap]);

  return <div ref={containerRef} style={{ width: "100%", height: "100%" }} />;
};

export default Map;
