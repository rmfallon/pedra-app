import React from "react";
import Map from "../components/Map";
import SearchBar from "../components/SearchBar";

const Home = () => {
  return (
    <div className="h-screen relative">
      {/* Main map container */}
      <div className="w-full h-full">
        <Map showEvents={true} />
      </div>

      {/* Search bar overlay */}
      <div className="absolute top-4 left-4 right-4 z-50">
        <SearchBar />
      </div>
    </div>
  );
};

export default Home;
