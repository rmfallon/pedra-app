import React from "react";
import Map from "../components/Map";
import SearchBar from "../components/SearchBar";

const Home = () => {
  return (
    <div className="relative" style={{ width: "100vw", height: "100vh" }}>
      <Map />
      <div className="absolute top-4 left-4 right-4 z-10 max-w-2xl">
        <SearchBar />
      </div>
    </div>
  );
};

export default Home;
